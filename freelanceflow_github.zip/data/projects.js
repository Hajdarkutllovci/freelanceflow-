export const projects = [
  { name: "Webseite für Kunde A", client: "Müller GmbH" },
  { name: "SEO Optimierung", client: "Freelance24" }
];